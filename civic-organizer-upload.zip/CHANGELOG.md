# Changelog

All notable user-facing changes are documented here.

## [0.1.0] - 2026-09-22
### Added
- Event planning with calendar export (`.ics`)
- Task tracking with owners, priorities and completion state
- Lightweight polls
- Inventory overview
- JSON backup and restore
- Responsive dashboard
- Offline-capable PWA shell
- Contribution, governance and security documentation
- Repository quality checks for CI

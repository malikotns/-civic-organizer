# Governance

Civic Organizer currently uses a maintainer-led governance model.

The primary maintainer is responsible for roadmap decisions, issue triage, pull-request review, releases, and security coordination. Contributors are encouraged to propose changes through issues and pull requests. As the contributor base grows, recurring contributors may be invited to become reviewers or core maintainers.

Project decisions should prioritize user safety, accessibility, privacy, maintainability, and usefulness to small volunteer organizations.

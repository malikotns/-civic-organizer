# Civic Organizer

A lightweight, dependency-free open-source organizer for small clubs, initiatives, volunteer teams and community groups.

**Live features:**
- Event planning
- Shared task tracking
- Simple polls
- Equipment / inventory overview
- Local browser storage
- JSON export and import
- Responsive layout

The project intentionally starts small: anyone can clone it, open `index.html`, and use it without installing a framework, database or cloud service.

## Why this project exists

Small volunteer organizations often end up coordinating work across chat messages, spreadsheets and paper notes. Civic Organizer aims to provide a simple, transparent starting point that can later grow into a self-hosted community workspace.

## Quick start

No build step is required.

1. Clone or download the repository.
2. Open `index.html` in a modern browser.
3. Add events, tasks, polls and inventory items.
4. Export your data as JSON whenever you want a backup.

For local development you can also run any simple static server, for example:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## GitHub Pages

This project can be published directly with GitHub Pages:

1. Open the repository settings on GitHub.
2. Go to **Pages**.
3. Choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`.
5. Save.

## Roadmap

Planned directions:
- [ ] Optional multi-user backend
- [ ] Authentication and organization workspaces
- [ ] Role-based permissions
- [ ] Recurring events
- [ ] Poll closing dates and one-vote-per-user mode
- [ ] Lending history for inventory
- [ ] Calendar export (ICS)
- [ ] Localization (German / English)
- [ ] Accessibility audit
- [ ] Automated tests

See [ROADMAP.md](ROADMAP.md) for more detail.

## Contributing

Contributions are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) before opening a pull request.

Good first contributions include:
- accessibility improvements
- translations
- better empty states
- validation improvements
- additional export formats
- documentation

## Project principles

1. **Useful before complex** — basic features should work without infrastructure.
2. **Privacy-friendly by default** — the current MVP stores data only in the browser.
3. **Easy to self-host** — no mandatory commercial service.
4. **Accessible and understandable** — features should remain approachable for non-technical volunteer teams.

## License

MIT — see [LICENSE](LICENSE).

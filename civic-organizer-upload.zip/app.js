const STORAGE_KEY = 'civic-organizer-v1';

const demoData = () => ({
  events: [
    { id: crypto.randomUUID(), title: 'Monthly planning meeting', date: futureDate(5), time: '18:30', location: 'Community room', notes: 'Review open tasks and next month.' },
    { id: crypto.randomUUID(), title: 'Volunteer onboarding', date: futureDate(12), time: '17:00', location: 'Online', notes: 'Welcome new volunteers and explain current projects.' }
  ],
  tasks: [
    { id: crypto.randomUUID(), title: 'Prepare meeting agenda', owner: 'Alex', due: futureDate(3), priority: 'high', done: false },
    { id: crypto.randomUUID(), title: 'Check shared equipment', owner: 'Sam', due: futureDate(8), priority: 'normal', done: false }
  ],
  polls: [
    { id: crypto.randomUUID(), question: 'Which evening works best for the next meeting?', options: [
      { label: 'Tuesday', votes: 2 }, { label: 'Wednesday', votes: 4 }, { label: 'Thursday', votes: 1 }
    ] }
  ],
  inventory: [
    { id: crypto.randomUUID(), name: 'Portable speaker', quantity: 1, location: 'Storage cabinet', owner: 'Team' },
    { id: crypto.randomUUID(), name: 'Folding tables', quantity: 3, location: 'Basement', owner: 'Team' }
  ]
});

function futureDate(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

let state = loadState();

function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : demoData();
  } catch {
    return demoData();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  renderAll();
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function formatDate(date) {
  if (!date) return 'No date';
  const d = new Date(`${date}T12:00:00`);
  return new Intl.DateTimeFormat(undefined, { year: 'numeric', month: 'short', day: 'numeric' }).format(d);
}


function escapeIcs(value = '') {
  return String(value)
    .replace(/\\/g, '\\\\')
    .replace(/\n/g, '\\n')
    .replace(/,/g, '\\,')
    .replace(/;/g, '\\;');
}

function compactDateTime(date, time = '00:00') {
  return `${date.replaceAll('-', '')}T${time.replace(':', '')}00`;
}

function exportCalendar() {
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Civic Organizer//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH'
  ];

  [...state.events].sort((a, b) => a.date.localeCompare(b.date)).forEach(event => {
    const start = compactDateTime(event.date, event.time || '00:00');
    const end = compactDateTime(event.date, event.time || '00:00');
    lines.push(
      'BEGIN:VEVENT',
      `UID:${escapeIcs(event.id)}@civic-organizer`,
      `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z')}`,
      `DTSTART:${start}`,
      `DTEND:${end}`,
      `SUMMARY:${escapeIcs(event.title)}`,
      event.location ? `LOCATION:${escapeIcs(event.location)}` : '',
      event.notes ? `DESCRIPTION:${escapeIcs(event.notes)}` : '',
      'END:VEVENT'
    );
  });

  lines.push('END:VCALENDAR');
  const blob = new Blob([lines.filter(Boolean).join('\r\n')], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `civic-organizer-${new Date().toISOString().slice(0, 10)}.ics`;
  a.click();
  URL.revokeObjectURL(url);
}

function renderStats() {
  const openTasks = state.tasks.filter(t => !t.done).length;
  const upcomingEvents = state.events.filter(e => e.date >= new Date().toISOString().slice(0, 10)).length;
  const totalVotes = state.polls.reduce((sum, p) => sum + p.options.reduce((s, o) => s + o.votes, 0), 0);
  const totalItems = state.inventory.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const stats = [
    ['Upcoming events', upcomingEvents],
    ['Open tasks', openTasks],
    ['Poll votes', totalVotes],
    ['Inventory units', totalItems]
  ];
  const host = document.querySelector('#stats');
  host.replaceChildren(...stats.map(([label, value]) => {
    const box = el('div', 'stat');
    box.append(el('strong', '', value), el('span', '', label));
    return box;
  }));
}

function renderDashboard() {
  const eventsHost = document.querySelector('#dashboardEvents');
  const tasksHost = document.querySelector('#dashboardTasks');
  const upcoming = [...state.events].filter(e => e.date >= new Date().toISOString().slice(0, 10)).sort((a,b) => a.date.localeCompare(b.date)).slice(0, 4);
  const tasks = state.tasks.filter(t => !t.done).slice(0, 4);
  eventsHost.replaceChildren(...(upcoming.length ? upcoming.map(eventRow) : [el('p', 'empty', 'No upcoming events.') ]));
  tasksHost.replaceChildren(...(tasks.length ? tasks.map(taskRow) : [el('p', 'empty', 'No open tasks.') ]));
}

function eventRow(event) {
  const row = el('div', 'item-row');
  const info = el('div');
  info.append(el('strong', '', event.title), el('div', 'meta', `${formatDate(event.date)}${event.time ? ` · ${event.time}` : ''}${event.location ? ` · ${event.location}` : ''}`));
  row.append(info);
  return row;
}

function taskRow(task) {
  const row = el('div', 'item-row' + (task.done ? ' done' : ''));
  const info = el('div');
  info.append(el('strong', task.priority === 'high' ? 'priority-high' : '', task.title), el('div', 'meta', `${task.owner || 'Unassigned'}${task.due ? ` · due ${formatDate(task.due)}` : ''}`));
  row.append(info);
  return row;
}

function renderEvents() {
  const host = document.querySelector('#eventList');
  const items = [...state.events].sort((a,b) => a.date.localeCompare(b.date));
  host.replaceChildren(...(items.length ? items.map(event => {
    const card = el('article', 'card');
    card.append(el('h3', '', event.title));
    card.append(el('p', 'meta', `${formatDate(event.date)}${event.time ? ` · ${event.time}` : ''}${event.location ? ` · ${event.location}` : ''}`));
    if (event.notes) card.append(el('p', '', event.notes));
    const del = el('button', 'button danger', 'Delete');
    del.addEventListener('click', () => { state.events = state.events.filter(x => x.id !== event.id); saveState(); });
    card.append(del);
    return card;
  }) : [el('p', 'empty', 'No events yet.') ]));
}

function renderTasks() {
  const host = document.querySelector('#taskList');
  host.replaceChildren(...(state.tasks.length ? state.tasks.map(task => {
    const row = el('div', 'panel item-row' + (task.done ? ' done' : ''));
    const info = el('div');
    const badge = el('span', 'badge', task.priority);
    info.append(el('strong', task.priority === 'high' ? 'priority-high' : '', task.title), el('div', 'meta', `${task.owner || 'Unassigned'}${task.due ? ` · ${formatDate(task.due)}` : ''}`), badge);
    const actions = el('div', 'header-actions');
    const toggle = el('button', 'button secondary', task.done ? 'Reopen' : 'Done');
    toggle.addEventListener('click', () => { task.done = !task.done; saveState(); });
    const del = el('button', 'button danger', 'Delete');
    del.addEventListener('click', () => { state.tasks = state.tasks.filter(x => x.id !== task.id); saveState(); });
    actions.append(toggle, del);
    row.append(info, actions);
    return row;
  }) : [el('p', 'empty', 'No tasks yet.') ]));
}

function renderPolls() {
  const host = document.querySelector('#pollList');
  host.replaceChildren(...(state.polls.length ? state.polls.map(poll => {
    const card = el('article', 'card');
    card.append(el('h3', '', poll.question));
    const options = el('div', 'poll-options');
    poll.options.forEach(option => {
      const row = el('div', 'poll-option');
      const label = el('span', '', `${option.label} · ${option.votes} vote${option.votes === 1 ? '' : 's'}`);
      const vote = el('button', '', 'Vote');
      vote.addEventListener('click', () => { option.votes += 1; saveState(); });
      row.append(label, vote);
      options.append(row);
    });
    const del = el('button', 'button danger', 'Delete poll');
    del.addEventListener('click', () => { state.polls = state.polls.filter(x => x.id !== poll.id); saveState(); });
    card.append(options, document.createElement('br'), del);
    return card;
  }) : [el('p', 'empty', 'No polls yet.') ]));
}

function renderInventory() {
  const host = document.querySelector('#inventoryList');
  host.replaceChildren(...(state.inventory.length ? state.inventory.map(item => {
    const card = el('article', 'card');
    card.append(el('h3', '', item.name));
    card.append(el('p', 'meta', `Quantity: ${item.quantity}${item.location ? ` · ${item.location}` : ''}${item.owner ? ` · ${item.owner}` : ''}`));
    const del = el('button', 'button danger', 'Delete');
    del.addEventListener('click', () => { state.inventory = state.inventory.filter(x => x.id !== item.id); saveState(); });
    card.append(del);
    return card;
  }) : [el('p', 'empty', 'No inventory items yet.') ]));
}

function renderAll() {
  renderStats();
  renderDashboard();
  renderEvents();
  renderTasks();
  renderPolls();
  renderInventory();
}

function wireForm(selector, buildItem, collection) {
  document.querySelector(selector).addEventListener('submit', event => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.currentTarget));
    state[collection].push(buildItem(data));
    event.currentTarget.reset();
    saveState();
  });
}

wireForm('#eventForm', data => ({ id: crypto.randomUUID(), ...data }), 'events');
wireForm('#taskForm', data => ({ id: crypto.randomUUID(), ...data, done: false }), 'tasks');
wireForm('#pollForm', data => ({
  id: crypto.randomUUID(),
  question: data.question,
  options: data.options.split(',').map(s => s.trim()).filter(Boolean).map(label => ({ label, votes: 0 }))
}), 'polls');
wireForm('#inventoryForm', data => ({ id: crypto.randomUUID(), ...data, quantity: Number(data.quantity) }), 'inventory');

document.querySelectorAll('.tab').forEach(tab => tab.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  tab.classList.add('active');
  document.querySelector(`#${tab.dataset.view}`).classList.add('active');
}));

document.querySelector('#resetDemoBtn').addEventListener('click', () => {
  if (confirm('Replace your current local data with demo data?')) {
    state = demoData();
    saveState();
  }
});

document.querySelector('#calendarBtn').addEventListener('click', exportCalendar);

document.querySelector('#exportBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `civic-organizer-${new Date().toISOString().slice(0,10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

document.querySelector('#importInput').addEventListener('change', async event => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    if (!parsed.events || !parsed.tasks || !parsed.polls || !parsed.inventory) throw new Error('Invalid shape');
    state = parsed;
    saveState();
  } catch {
    alert('That file does not look like a Civic Organizer export.');
  } finally {
    event.target.value = '';
  }
});

renderAll();


if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {
      // Offline support is optional; the app still works without a service worker.
    });
  });
}

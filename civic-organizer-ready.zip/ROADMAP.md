# Roadmap

This roadmap is directional rather than a promise of release dates.

## 0.1 — local-first MVP
- [x] Events
- [x] Tasks
- [x] Polls
- [x] Inventory
- [x] JSON backup / restore
- [x] ICS calendar export
- [x] Offline-capable app shell
- [x] CI and maintainer documentation

## 0.2 — quality and accessibility
- [ ] Full keyboard and screen-reader audit
- [ ] Structured import validation and migration support
- [ ] German / English localization
- [ ] Recurring events
- [ ] Task filters and labels
- [ ] Poll closing dates
- [ ] Automated browser tests

## 0.3 — optional collaboration
- [ ] Pluggable persistence adapter
- [ ] Self-hosted multi-user backend reference implementation
- [ ] Organization workspaces
- [ ] Role-based permissions
- [ ] One-vote-per-user poll mode
- [ ] Equipment lending history

## Longer term
- [ ] CalDAV / calendar integrations
- [ ] Document links and meeting minutes
- [ ] Notification adapters
- [ ] Importers for common spreadsheet formats
- [ ] Maintainer automation for issue triage, review and releases

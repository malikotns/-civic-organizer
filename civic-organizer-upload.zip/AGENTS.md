# AGENTS.md

Guidance for coding agents and human contributors working on Civic Organizer.

## Project goals
- Keep the default experience privacy-friendly and easy to self-host.
- Prefer platform features and small modules over heavy dependencies.
- Preserve accessibility, keyboard usability and mobile support.
- Never introduce mandatory telemetry or third-party tracking.

## Before changing code
1. Read `README.md`, `CONTRIBUTING.md`, `ROADMAP.md`, and `SECURITY.md`.
2. Keep changes scoped to one issue when possible.
3. Do not add secrets, personal data or organization-specific content.

## Validation
Run:
```bash
node --check app.js
python3 scripts/quality_check.py
```

For behavior changes, start a local server and manually exercise the affected workflow:
```bash
python3 -m http.server 8000
```

## Pull requests
Summarize the user impact, note manual tests, and update `CHANGELOG.md` for user-visible changes.

# Contributing

Thanks for considering a contribution to Civic Organizer.

## Before you start

For substantial changes, open an issue first so the problem and approach can be discussed.

## Development

The current version has no external dependencies. You can run it with any static web server:

```bash
python3 -m http.server 8000
```

## Pull requests

Please:

1. Keep changes focused.
2. Test the app in a current desktop and mobile browser size.
3. Preserve keyboard usability.
4. Update documentation when behavior changes.
5. Describe what changed and why.

## Commit messages

Short, descriptive messages are preferred, for example:

- `Add task due-date filter`
- `Improve poll accessibility`
- `Document GitHub Pages deployment`

## Reporting bugs

Include:
- browser and operating system
- steps to reproduce
- expected result
- actual result
- screenshots if useful

# Code of Conduct

We want Civic Organizer to be a welcoming project for contributors with different backgrounds and levels of experience.

Be respectful, assume good faith, focus criticism on ideas and code rather than people, and avoid harassment or discriminatory language.

Maintainers may remove contributions or participation that repeatedly violates these expectations.

---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

## Problem

What problem would this solve for a group or volunteer team?

## Proposed solution

## Alternatives considered

## Additional context

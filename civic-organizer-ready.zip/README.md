# Civic Organizer

A lightweight, privacy-friendly open-source organizer for small clubs, initiatives, volunteer teams and community groups.

Civic Organizer is intentionally easy to run: clone the repository, serve the static files, and start planning. No framework, account, database, analytics service or cloud subscription is required for the current release.

## Features

- Event planning and `.ics` calendar export
- Shared task tracking with owners, priorities and due dates
- Simple polls
- Equipment and inventory overview
- Local-first browser storage
- JSON backup and restore
- Installable/offline-capable PWA shell
- Responsive layout for phones and desktops

## Why this project exists

Small volunteer organizations often coordinate work across chat threads, spreadsheets, paper notes and several specialized services. Civic Organizer provides a simple open foundation that can be self-hosted and extended without forcing a group into a proprietary platform.

The project starts deliberately small so new contributors can understand the entire codebase quickly. The long-term goal is a modular community workspace that keeps privacy and self-hosting viable as collaboration features are added.

## Quick start

No build step is required.

```bash
git clone https://github.com/YOUR-USERNAME/civic-organizer.git
cd civic-organizer
python3 -m http.server 8000
```

Open `http://localhost:8000`.

Opening `index.html` directly also works for the core app, but a local HTTP server is recommended because browser service workers require HTTP(S).

## Project status

**v0.1.0 — early public release.** The local-first MVP is usable, but the project is still young. Feedback, accessibility testing, translations and deployment reports are especially useful.

See [ROADMAP.md](ROADMAP.md) and [CHANGELOG.md](CHANGELOG.md).

## Repository structure

```text
index.html                 App shell and accessible forms
styles.css                 Responsive UI
app.js                     State, rendering, import/export and calendar export
manifest.webmanifest       Installable web app metadata
sw.js                      First-party offline asset cache
scripts/quality_check.py   Dependency-free repository checks
.github/workflows/         Continuous integration
docs/                      Architecture and privacy notes
```

## Principles

1. **Useful before complex** — core workflows should remain easy to understand.
2. **Privacy-friendly by default** — no mandatory analytics, tracking or remote storage.
3. **Easy to self-host** — a static web server is enough for the MVP.
4. **Accessible and approachable** — the intended users include non-technical volunteer teams.
5. **Open maintenance** — roadmap, security policy and contribution expectations live in the repository.

## Contributing

Issues and pull requests are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) and [AGENTS.md](AGENTS.md).

Useful first contributions include accessibility improvements, translations, validation improvements, better empty states, documentation and additional export formats.

## Security and privacy

Read [SECURITY.md](SECURITY.md) before reporting security-sensitive issues. The current architecture and privacy model are documented in [docs/architecture.md](docs/architecture.md) and [docs/privacy.md](docs/privacy.md).

## Governance

The project currently uses a maintainer-led model. See [GOVERNANCE.md](GOVERNANCE.md).

## License

MIT — see [LICENSE](LICENSE).

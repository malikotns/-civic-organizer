# Security Policy

## Supported versions
Security fixes target the latest release on the `main` branch.

## Reporting a vulnerability
Please do **not** open a public issue for a vulnerability that could put users or their data at risk. Use GitHub's private vulnerability reporting feature when enabled. If that is unavailable, contact the maintainer privately through the address listed on the maintainer's GitHub profile.

Include reproduction steps, affected files or versions, and the expected security impact. Please avoid accessing data you do not own.

## Security model
The current MVP is a static client-side application. It has no server, accounts, analytics, or remote database. Data is stored in browser `localStorage` unless the user exports it. This reduces server-side attack surface but means anyone with access to the browser profile may be able to read the stored data.

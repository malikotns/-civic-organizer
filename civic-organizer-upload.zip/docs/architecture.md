# Architecture

Civic Organizer 0.1.x is deliberately a static web application. `index.html` provides the semantic UI, `styles.css` contains presentation, and `app.js` owns local state and rendering. Browser `localStorage` is the only persistence layer.

The design keeps installation and self-hosting friction close to zero. Future multi-user work should be introduced behind an optional adapter so the local-first mode remains available.

## Trust boundaries
- No backend is trusted because no backend is required.
- Imported JSON must be treated as untrusted input and validated before replacing local state.
- User text is inserted through `textContent`, not `innerHTML`.
- Service-worker caching is limited to first-party static assets.

#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    'index.html', 'styles.css', 'app.js', 'LICENSE', 'README.md',
    'CONTRIBUTING.md', 'SECURITY.md', 'GOVERNANCE.md', 'CHANGELOG.md',
    'AGENTS.md', 'manifest.webmanifest', 'sw.js'
]
missing = [name for name in required if not (ROOT / name).exists()]
if missing:
    print('Missing required files:', ', '.join(missing))
    sys.exit(1)

html = (ROOT / 'index.html').read_text(encoding='utf-8')
for element_id in ['stats','eventForm','taskForm','pollForm','inventoryForm','calendarBtn','exportBtn','importInput']:
    if f'id="{element_id}"' not in html:
        print(f'Missing required DOM id: {element_id}')
        sys.exit(1)

app = (ROOT / 'app.js').read_text(encoding='utf-8')
if 'innerHTML' in app:
    print('Avoid innerHTML for user-provided content.')
    sys.exit(1)
if 'localStorage' not in app:
    print('Expected local-first persistence is missing.')
    sys.exit(1)

print('Repository quality checks passed.')

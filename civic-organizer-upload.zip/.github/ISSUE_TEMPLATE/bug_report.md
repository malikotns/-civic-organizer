---
name: Bug report
about: Report something that is not working
labels: bug
---

## What happened?

## How can we reproduce it?

1.
2.
3.

## What did you expect?

## Environment

- Browser:
- Operating system:

## Additional context

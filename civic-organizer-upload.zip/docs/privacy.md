# Privacy

Civic Organizer is local-first. The current release does not send application data to a server, analytics provider or advertising network. Events, tasks, polls and inventory are stored in the browser's local storage.

Users can export a JSON backup and an ICS calendar file. Those exported files may contain names, dates, locations and notes, so users should handle them according to their own privacy requirements.

Future networked features must be optional and documented before release.

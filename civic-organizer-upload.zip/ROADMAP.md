# Roadmap

## v0.1 — Local-first MVP

- Events
- Tasks
- Polls
- Inventory
- JSON import/export
- Responsive UI

## v0.2 — Quality and accessibility

- Keyboard-navigation review
- Screen-reader labels and announcements
- Form validation improvements
- Automated smoke tests
- German localization
- Better date handling

## v0.3 — Collaboration

- Optional backend adapter
- User accounts
- Organization workspaces
- Roles and permissions
- Audit log

## v0.4 — Community operations

- Recurring events
- ICS calendar import/export
- Equipment lending history
- Poll deadlines
- Meeting notes
- Task labels and filters

## Long-term ideas

- Self-hosted Docker deployment
- Pluggable storage providers
- Public API
- Mobile-friendly PWA mode
- Notification integrations

## What changed?

## Why?

## How was it tested?

- [ ] Desktop browser
- [ ] Mobile-sized viewport
- [ ] Keyboard interaction
- [ ] Documentation updated if needed
